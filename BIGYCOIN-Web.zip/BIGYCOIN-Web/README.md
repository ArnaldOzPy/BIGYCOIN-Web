# BIGYCOIN Web

Sitio oficial para la criptomoneda BIGYCOIN (BIG GUARANI COIN), lista para usar con MetaMask, verificar saldo y enviar tokens.

## Tecnologías
- HTML5
- CSS3
- JavaScript (Web3.js)
- MetaMask

## ¿Cómo usar?
1. Clona o descarga el repositorio.
2. Reemplaza `tokenAddress` en `js/web3-handler.js` por la dirección de tu contrato desplegado.
3. Sube a GitHub Pages.

© 2025 Arnaldo Ozorio
